import TCPMessagingComponent from "../../CommonComponents/TCPMessagingComponent";
import "./Chat.css"

class Chat extends TCPMessagingComponent{
    constructor(props) {
        super(props);

    }

    render() {
        return (
            <section className="Chat">

            </section>
        );
    }

}

export default Chat;